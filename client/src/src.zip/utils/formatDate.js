// client/src/utils/formatDate.js

export const formatDate = (dateString) => {
    const date = new Date(dateString);
    const year = date.getFullYear();
    const monthNames = [
      'янв', // Январь
      'фев', // Февраль
      'мар', // Март
      'апр', // Апрель
      'май', // Май
      'июн', // Июнь
      'июл', // Июль
      'авг', // Август
      'сен', // Сентябрь
      'окт', // Октябрь
      'ноя', // Ноябрь
      'дек', // Декабрь
    ];
    const month = monthNames[date.getMonth()]; // Ойни кискартирилган шаклида олиш
    const day = String(date.getDate()).padStart(2, '0'); // Кунни 2 хонали килиш
  
    // Формат: 2025г.17фев
    return `${year}г.${day}${month}`;
  };