import React from 'react';


const Login = () => {
  const handleGoogleLogin = async () => {
    window.location.href = 'http://localhost:5000/auth/google';
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Добро пожаловать!</h1>
      <button onClick={handleGoogleLogin} style={{ padding: '10px 20px', fontSize: '16px' }}>
        Войти через Google
      </button>
    </div>
  );
};

export default Login;
