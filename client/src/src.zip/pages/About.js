import React from 'react';

const About = () => {
  return (
    <div className="container mt-5">
      <h2>Трекер долгов</h2>
      <p>
      Этот проект помогает пользователям управлять своей задолженностью. У вас есть несколько
      Вы можете использовать функции для отслеживания выданных и полученных вами займов.
      </p>
      <p>
      Если у вас есть вопросы, вы можете связаться с нами:
        <br />
        Email: support@debttracker.com
      </p>
    </div>
  );
};

export default About;