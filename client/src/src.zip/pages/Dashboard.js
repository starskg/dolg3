import React, { useState, useEffect } from 'react';
import axios from 'axios';
import AddDebtForm from '../components/AddDebtForm';
import DebtList from '../components/DebtList';
import PlusButton from '../components/PlusButton'; // Импортируем компонент кнопки

const Dashboard = () => {
  const [user, setUser] = useState(null);
  const [debts, setDebts] = useState([]);
  const [filter, setFilter] = useState('all');
  const [showMenu, setShowMenu] = useState(false);
  const [selectedType, setSelectedType] = useState(null);
  const [editingDebt, setEditingDebt] = useState(null);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/user', {
          withCredentials: true,
        });
        console.log('User data:', response.data); // Логируем данные пользователя
        setUser(response.data);
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };
    fetchUserData();
  }, []);

  useEffect(() => {
    const fetchDebts = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/debts', {
          withCredentials: true,
        });
        console.log('Debt data:', response.data); // Логируем данные долгов
        setDebts(response.data);
      } catch (error) {
        console.error('Error fetching debt data:', error);
      }
    };
    fetchDebts();
  }, []);

  const totalAmount = debts.reduce((sum, debt) => sum + parseFloat(debt.amount), 0);

  const filteredDebts = debts.filter((debt) => {
    if (filter === 'all') return true;
    if (filter === 'given') return debt.type === 'given';
    if (filter === 'taken') return debt.type === 'taken';
    return false;
  });

  const handleDeleteDebt = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/debts/${id}`, {
        withCredentials: true,
      });
      setDebts(debts.filter((debt) => debt.id !== id));
    } catch (error) {
      console.error('Error deleting debt:', error);
    }
  };

  const handleEditDebt = (debt) => {
    setEditingDebt(debt);
    setSelectedType(debt.type);
  };

  const handleUpdateDebt = async (updatedDebt) => {
    try {
      await axios.put(`http://localhost:5000/api/debts/${updatedDebt.id}`, updatedDebt, {
        withCredentials: true,
      });
      setDebts(
        debts.map((debt) => (debt.id === updatedDebt.id ? updatedDebt : debt))
      );
      setEditingDebt(null);
    } catch (error) {
      console.error('Error updating debt:', error);
    }
  };

  if (!user) {
    return <div>Загрузка данных пользователя...</div>;
  }

  if (debts.length === 0) {
    return <div>Загрузка долгов...</div>;
  }

  return (
    <div className="container mt-4">
      {user && (
        <h1 className="text-primary">
          Привет, <strong>{user.name}</strong>!
        </h1>
      )}

      <p className="fs-4">
        Общий сумма: <strong>{totalAmount.toFixed(2)} сом</strong>
      </p>

      <div className="btn-group mb-3" role="group" aria-label="Filter buttons">
        <button
          type="button"
          className={`btn ${filter === "all" ? "btn-primary" : "btn-outline-primary"}`}
          onClick={() => setFilter("all")}
        >
          Все
        </button>
        <button
          type="button"
          className={`btn ${filter === "given" ? "btn-success" : "btn-outline-success"}`}
          onClick={() => setFilter("given")}
        >
          Мне должны
        </button>
        <button
          type="button"
          className={`btn ${filter === "taken" ? "btn-danger" : "btn-outline-danger"}`}
          onClick={() => setFilter("taken")}
        >
          Я должен
        </button>
      </div>

      <DebtList debts={filteredDebts} onDelete={handleDeleteDebt} onEdit={handleEditDebt} onUpdate={handleUpdateDebt} />

      <PlusButton setShowMenu={setShowMenu} showMenu={showMenu} setSelectedType={setSelectedType} />

      {(selectedType || editingDebt) && (
        <AddDebtForm onAdd={() => setSelectedType(null)} onUpdate={handleUpdateDebt} defaultType={selectedType} editingDebt={editingDebt} />
      )}
    </div>
  );
};

export default Dashboard;
