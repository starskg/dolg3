import React from 'react';
import { Link } from 'react-router-dom';

const Header = () => {
  return (
    <header className="bg-primary text-white py-3">
      <div className="container d-flex justify-content-between align-items-center">
        {/* Лого */}
        <h1 className="mb-0">
          <Link to="/" className="text-white text-decoration-none">
          Трекер долгов
          </Link>
        </h1>

        {/* Навигация */}
        <nav>
          <ul className="list-unstyled d-flex gap-3 mb-0">
            <li>
              <Link to="/dashboard" className="text-white text-decoration-none">
                Дашборд
              </Link>
            </li>
            <li>
              <Link to="/about" className="text-white text-decoration-none">
              Информация
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;