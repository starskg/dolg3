import React, { useState } from 'react';
import { formatDate } from '../utils/formatDate';
import { FaEdit, FaTrash } from 'react-icons/fa';

const DebtList = ({ debts, onDelete, onUpdate }) => {
  const [activeRow, setActiveRow] = useState(null);
  const [editingId, setEditingId] = useState(null);
  const [editedDebt, setEditedDebt] = useState({});

  const handleRowClick = (id) => {
    setActiveRow(activeRow === id ? null : id); // Toggle row visibility
  };

  const handleEdit = (debt) => {
    setEditingId(debt.id);
    setEditedDebt({
      debtor_name: debt.debtor_name,
      amount: debt.amount,
      date: debt.date,
    });
  };

  const handleSave = async () => {
    try {
      await onUpdate(editingId, editedDebt);
      setEditingId(null);  // Close the editing mode
      setActiveRow(null);   // Hide the active row
    } catch (error) {
      console.error('Ошибка при обновлении:', error);
    }
  };

  const handleCancel = () => {
    setEditingId(null); // Close editing mode
    setActiveRow(null); // Hide the active row
    setEditedDebt({});  // Reset edited debt data
  };

  return (
    <div onClick={() => setActiveRow(null)}> {/* Close active row when clicking elsewhere */}
      {debts.length > 0 ? (
        <table className="table table-striped">
          <thead>
            <tr>
              <th>Имя</th>
              <th>Сумма</th>
              <th>Дата</th>
              <th>Действия</th>
            </tr>
          </thead>
          <tbody>
            {debts.map((debt) => (
              <tr
                key={debt.id}
                onClick={(e) => {
                  e.stopPropagation();
                  handleRowClick(debt.id);
                }}
              >
                {editingId === debt.id ? (
                  <>
                    <td>
                      <input
                        type="text"
                        value={editedDebt.debtor_name}
                        onChange={(e) => setEditedDebt({ ...editedDebt, debtor_name: e.target.value })}
                        className="form-control"
                      />
                    </td>
                    <td>
                      <input
                        type="number"
                        value={editedDebt.amount}
                        onChange={(e) => setEditedDebt({ ...editedDebt, amount: e.target.value })}
                        className="form-control"
                      />
                    </td>
                    <td>
                      <input
                        type="date"
                        value={editedDebt.date}
                        onChange={(e) => setEditedDebt({ ...editedDebt, date: e.target.value })}
                        className="form-control"
                      />
                    </td>
                    <td>
                      <button onClick={handleSave} className="btn btn-success me-2">
                        Сохранить
                      </button>
                      <button onClick={handleCancel} className="btn btn-secondary">
                        Отмена
                      </button>
                    </td>
                  </>
                ) : (
                  <>
                    <td>{debt.debtor_name}</td>
                    <td>{debt.amount} сом</td>
                    <td>{formatDate(debt.date)}</td>
                    <td>
                      <FaEdit
                        className="text-warning me-2"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleEdit(debt);
                        }}
                      />
                      <FaTrash
                        className="text-danger"
                        onClick={(e) => {
                          e.stopPropagation();
                          onDelete(debt.id);
                        }}
                      />
                      {activeRow === debt.id && editingId !== debt.id && (
                        <span className="ms-2">
                          <button onClick={() => handleEdit(debt)} className="btn btn-warning me-2">
                            Изменить
                          </button>
                          <button onClick={() => onDelete(debt.id)} className="btn btn-danger me-2">
                            Удалить
                          </button>
                        </span>
                      )}
                    </td>
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p className="text-muted">Долгов нет.</p>
      )}
    </div>
  );
};

export default DebtList;
