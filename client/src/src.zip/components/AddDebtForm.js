import React, { useState } from 'react';
import axios from 'axios';
import styles from './AddDebtForm.module.css';

const AddDebtForm = ({ onAdd, defaultType }) => {
  const [formData, setFormData] = useState({
    debtor_name: '',
    amount: '',
    type: defaultType || 'given', // Тип долга (дан/взятый)
    comment: '',
    date: new Date().toISOString().split('T')[0], // Устанавливаем текущую дату
  });
  const [successMessage, setSuccessMessage] = useState('');

  // Обновление данных формы
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  // Отправка формы
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Получение данных пользователя
      const userResponse = await axios.get('http://localhost:5000/api/user', {
        withCredentials: true,
      });
      const userId = userResponse.data.id;

      // Отправка запроса на сохранение долга
      await axios.post(
        'http://localhost:5000/api/debts',
        {
          ...formData,
          user_id: userId,
        },
        { withCredentials: true }
      );

      // Отображение сообщения об успешном добавлении
      setSuccessMessage('Долг успешно добавлен!');
      setTimeout(() => setSuccessMessage(''), 3000);
      onAdd(); // Обновление списка долгов
    } catch (error) {
      console.error('Ошибка при сохранении долга:', error);
    }
  };

  // Функция отмены
  const handleCancel = () => {
    setFormData({
      debtor_name: '',
      amount: '',
      type: defaultType || 'given',
      comment: '',
      date: new Date().toISOString().split('T')[0],
    });
    onAdd(); // Закрытие формы
  };

  return (
    <form onSubmit={handleSubmit} className={styles.formContainer}>
      <h3>{formData.type === 'given' ? 'Дать в долг' : 'Взять в долг'}</h3>
      <div>
        <label>Имя:</label>
        <input
          type="text"
          name="debtor_name"
          value={formData.debtor_name}
          onChange={handleChange}
          required
          className={styles.inputField}
        />
      </div>
      <div>
        <label>Сумма:</label>
        <input
          type="number"
          name="amount"
          value={formData.amount}
          onChange={handleChange}
          required
          className={styles.inputField}
        />
      </div>
      <div>
        <label>Тип:</label>
        <select
          name="type"
          value={formData.type}
          onChange={handleChange}
          className={styles.inputField}
        >
          <option value="given">Я дал в долг</option>
          <option value="taken">Я взял в долг</option>
        </select>
      </div>
      <div>
        <label>Комментарий:</label>
        <textarea
          name="comment"
          value={formData.comment}
          onChange={handleChange}
          className={styles.inputField}
        />
      </div>
      <div>
        <label>Дата:</label>
        <input
          type="date"
          name="date"
          value={formData.date}
          onChange={handleChange}
          required
          className={styles.inputField}
        />
      </div>

      {/* Кнопки "Сохранить" и "Отмена" */}
      <div style={{ display: 'flex', gap: '10px', marginTop: '20px' }}>
        <button type="submit" className={styles.submitButton}>
          Сохранить
        </button>
        <button
          type="button"
          onClick={handleCancel}
          style={{
            padding: '10px 20px',
            backgroundColor: '#dc3545',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer',
          }}
        >
          Отмена
        </button>
      </div>

      {/* Отображение сообщения */}
      {successMessage && (
        <p className={styles.successMessage}>{successMessage}</p>
      )}
    </form>
  );
};

export default AddDebtForm;
