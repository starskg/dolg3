import React, { useState, useEffect } from 'react';
import plusButton from '../img/plus-button.svg';

const PlusButton = ({ setShowMenu, showMenu, setSelectedType }) => {
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    if (showMenu) {
      // Menyu ko'rsatilgandan so'ng kichik kechikish bilan animatsiyani boshlash
      setTimeout(() => {
        setAnimate(true);
      }, 10);
    } else {
      // Menyu yopilganda darhol animatsiyani bekor qilish
      setAnimate(false);
    }
  }, [showMenu]);

  return (
    <>
      {/* "+" tugmasi */}
      <button
        onClick={() => setShowMenu(!showMenu)}
        className="btn btn-primary rounded-circle position-fixed"
        style={{
          bottom: '80px',
          left: '50%',
          transform: `translateX(-50%) rotate(${showMenu ? 135 : 0}deg)`,
          transformOrigin: 'center center',
          width: '70px',
          height: '70px',
          fontSize: '24px',
          zIndex: 1060,
          transition: 'transform 0.2s ease-in-out',
          padding: 0,
          border: 'none',
          background: 'none',
        }}
      >
        <img
          src={plusButton}
          alt="Plus button"
          style={{ width: '100%', height: '100%', pointerEvents: 'none' }}
        />
      </button>

      {/* Menyu */}
      {showMenu && (
        <>
          {/* Fon */}
          <div
            onClick={() => setShowMenu(false)}
            className="position-fixed top-0 start-0 w-100 h-100"
            style={{ zIndex: 1040, backgroundColor: "rgba(0,0,0,0.3)" }}
          />
          {/* "Взять долг" varianti */}
          <div
            className="position-fixed"
            style={{
              bottom: "130px",
              left: "calc(50% + 90px)",
              zIndex: 1050,
              transform: animate
                ? "translateX(-50%) translateY(0) scale(1)"
                : "translateX(-50%) translateY(20px) scale(0.8)",  // Kattalashish effekti
              opacity: animate ? 1 : 0,
              transition: 'opacity 0.3s ease-out, transform 0.2s ease-out',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => {
                setSelectedType('taken');
                setShowMenu(false);
              }}
              className="btn btn-danger"
            >
              Взять долг
            </button>
          </div>
          {/* "Дать долг" varianti */}
          <div
            className="position-fixed"
            style={{
              bottom: "130px",
              left: "calc(50% - 90px)",
              zIndex: 1050,
              transform: animate
                ? "translateX(-50%) translateY(0) scale(1)"
                : "translateX(-50%) translateY(20px) scale(0.8)",  // Kattalashish effekti
              opacity: animate ? 1 : 0,
              transition: 'opacity 0.3s ease-out, transform 0.2s ease-out',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => {
                setSelectedType('given');
                setShowMenu(false);
              }}
              className="btn btn-success"
            >
              Дать долг
            </button>
          </div>
        </>
      )}
    </>
  );
};

export default PlusButton;
